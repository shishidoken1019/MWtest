<?php

//
require_once('base.inc');
require_once('controller.inc');

//
$cobj = new controller;
$cobj->set_config($config);
$cobj->run();
